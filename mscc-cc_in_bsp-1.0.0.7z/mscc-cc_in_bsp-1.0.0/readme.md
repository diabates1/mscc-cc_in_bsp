
This is an empty repository for fake or empty toolchain.
This isused by EBS version which needs a repository to be selected for toolchain binary.
Indeed in some case binary are not needed and comes from another package...
However, we still need to define some variables... !
